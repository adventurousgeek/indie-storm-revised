
<?php require_once __DIR__ . '/common-components/header.php'; ?>
<main class="site-main">
	<?php require_once __DIR__ . '/components/home.php'; ?>
</main>
<?php require_once __DIR__ . '/common-components/footer.php'; ?>



	
	
